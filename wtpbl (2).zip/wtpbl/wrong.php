<!DOCTYPE html>
<html>
    <head>
        <title>
            Wrong Credentials
        </title>
        <style>
            body {
            overflow-x: hidden;
            margin: 0px;
            font-family: Georgia, 'Times New Roman', Times, serif;
            font-size: 20px;
        }
        section{
            display:block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 100px;
            text-align: center;
            padding-top: 30px;
        }
        h1{
            /* text-align: center; */
            font-size: 30px;
            color: red;
        }
        </style>
    </head>
    <body>
        <section>
            <h1>Wrong Credentials</h1>
            <p>Go back to <a href="login.php">login</a> page</p>
        </section>
        
    </body>
</html>