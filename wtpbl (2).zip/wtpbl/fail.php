<!DOCTYPE html>
<html>
    <head>
        <style>
            body{
                text-align: center;
            }
            h1{
                text-align: center;
                font-size: 30px;
                color: red;
            }
        </style>
    </head>
    <body>
        <h1>Oops! Something went wrong.</h1>
        <a href="appointment.php">Click here</a> to go back to appointment booking
    </body>
</html>