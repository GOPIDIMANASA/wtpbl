<!DOCTYPE html>
<html>
<head>
    <title>NewLife Hospitals-Login</title>
    <link rel="stylesheet" href="login.css"/>
</head>
<body>
<img id="d4" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqEPqmPG1zOwPa6NLzJ6XOKapRIDSdIwLWqQrlfClUMj0e6SXs2_82sGjXoOuKTAmyqQE&usqp=CAU" alt="logo" id="logo">
 
    <button onclick="window.location.href='plogin.php'">Login for Patients</button><br>
    <button onclick="window.location.href='dlogin.php'">Login for Doctors</button>
</html>