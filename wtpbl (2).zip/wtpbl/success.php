<!DOCTYPE html>
<html>
    <head>
        <style>
            h1{
                text-align: center;
                font-size: 30px;
                color: green;
            }
        </style>
    </head>
    <body>
        <h1>Appointment booked successfully!</h1>
    </body>
</html>